# KM_Instance_Segmentation > 2025-05-01 10:11pm
https://universe.roboflow.com/charithworkspace/km_instance_segmentation

Provided by a Roboflow user
License: CC BY 4.0

